package com.global.knowledge;

public interface Constant {

	public static final String QUESTION = "question";
	public static final String ANSWER_A = "answerA";
	public static final String ANSWER_B = "answerB";
	public static final String ANSWER_C = "answerC";
	public static final String ANSWER_D = "answerD";
	public static final String ANSWER_E = "answerE";
	public static final String CORRECT_ANS = "correctAnswer";
	public static final String EXPLANATION = "explanation";

	String[] correctAns = { "A", "B", "C", "D", "E" };

	public static final String APP_ID = "172552689469417";

	static final String[] PERMISSIONS = new String[] { "publish_stream" };

	public static String twitter_consumer_key = "uoG8vtpVT0jalxwVfhv7Q";
	public static String twitter_secret_key = "dVK9IfJ3D4Qwety1mIljLmH1gCylEomY06Si1vaRHw";
	
	public String link = "http://www.globalknowledge.com/training/generic.asp?pageid=3196&country=United+States";
	
}
